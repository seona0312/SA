#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inode.h>
#include <njson.h>
#include <nutil.h>
#include <icode.x.h>

#if defined XWIN32
#include <Windows.h>
#endif

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//////                                                                   //////
//////                                                                   //////
//////                          User Function                            //////
//////                                                                   //////
//////                                                                   //////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/*****************************************************************************/
/*****************************************************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*****************************                ********************************/
/*******************************            **********************************/
/*********************************        ************************************/
/************************************   **************************************/
/************************************* ***************************************/
/*****************************************************************************/
#include <nTCPClient.h>
#include <nSerial.h>
#include <nwsc.h>

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//////                                                                   //////
//////                                                                   //////
//////                         SYSTEM CALLBACK                           //////
//////                                                                   //////
//////                                                                   //////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/*****************************************************************************/
/*****************************************************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*****************************                ********************************/
/*******************************            **********************************/
/*********************************        ************************************/
/************************************   **************************************/
/************************************* ***************************************/
/*****************************************************************************/

int32_t (*inode_wss_write)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);
int32_t (*inode_httpd_write)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);




int32_t inode_on_wss_connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf("inode_on_wss_connected \r\n");

  return 0;
}


int32_t inode_on_wss_disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{

  printf("inode_on_wss_disconnected \r\n");

  return 0;
}


int32_t inode_on_wss_read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{

  printf("inode_on_wss_read \r\n");

  return 0;
}

int32_t inode_on_httpd_connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{

  printf("inode_on_httpd_connected \r\n");

  return 0;
}


int32_t inode_on_httpd_disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf("inode_on_httpd_disconnected \r\n");

  return 0;
}


int32_t inode_on_httpd_read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf("inode_on_httpd_read \r\n");

  return 0;
}


int32_t inode_on_httpd_cgi_get(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf("inode_on_httpd_cgi_get (%s)\r\n\r\n\r\n%s\r\n\r\n", (int8_t*)moreinfo, (int8_t*)b );

  return 0;
}

int32_t inode_on_httpd_cgi_post(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  int8_t jbuf[1024];
  int32_t e = 0;
  printf("inode_on_httpd_cgi_post (%s)\r\n\r\n\r\n%s\r\n\r\n", (int8_t*)moreinfo, (int8_t*)b );

  if ( strncmp((int8_t*)moreinfo, "/readplc", strlen((int8_t*)moreinfo)) == 0 )
  {
    ///// /readplc processor

    sprintf(jbuf,
              "{"
                "\"version\": \"2.0\","
                "\"template\":"
                "{"
                  "\"outputs\":"
                  "["
                    "{"
                      "\"simpleText\":"
                      "{"
                        "\"text\":"
                        "\"%s\""
                      "}"
                    "}"
                  "]"
                "}"
              "}",
            //strlen(hbuf),
            "02 03 04 05"
            );


    e = inode_httpd_write(h, fd, jbuf, strlen(jbuf), 0, o);
    if ( e < 0 ) printf(" error -> %08X \r\n", e);
  }


  return 0;
}


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//////                                                                   //////
//////                                                                   //////
//////                           Entry Point                             //////
//////                                                                   //////
//////                                                                   //////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/*****************************************************************************/
/*****************************************************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*********************************        ************************************/
/*****************************                ********************************/
/*******************************            **********************************/
/*********************************        ************************************/
/************************************   **************************************/
/************************************* ***************************************/
/*****************************************************************************/

void* nmain(void* hdl, void** _wss_iohandler, void** _httpd_iohandler, void** iohandler, void* obj)
{
  static iNode inode;
  memset(&inode, 0, sizeof(iNode));

  inode.inode_wss_write = *(_wss_iohandler+ICODE_WRITE);
  inode.inode_wss_fdset = *(_wss_iohandler+ICODE_FDSET);
  *(_wss_iohandler+ICODE_CALLBACK_CONNECTED) = inode_on_wss_connected;
  *(_wss_iohandler+ICODE_CALLBACK_DISCONNECTED) = inode_on_wss_disconnected;
  *(_wss_iohandler+ICODE_CALLBACK_READ) = inode_on_wss_read;

  inode.inode_httpd_write = *(_httpd_iohandler+ICODE_WRITE);
  inode.inode_httpd_fdset = *(_httpd_iohandler+ICODE_FDSET);
  *(_httpd_iohandler+ICODE_CALLBACK_CONNECTED) = inode_on_httpd_connected;
  *(_httpd_iohandler+ICODE_CALLBACK_DISCONNECTED) = inode_on_httpd_disconnected;
  *(_httpd_iohandler+ICODE_CALLBACK_READ) = inode_on_httpd_read;
  *(_httpd_iohandler+ICODE_CALLBACK_CGI_GET) = inode_on_httpd_cgi_get;
  *(_httpd_iohandler+ICODE_CALLBACK_CGI_POST) = inode_on_httpd_cgi_post;

  inode.hdl = hdl;
  obj = &inode;
  inode.log = *(iohandler+0xF);

  //nTCPClient(&inode);
  //nSerial(&inode);
  nwsc(&inode);
  while ( 1 )
  {

    delay(1);
  }


  return 0;
}