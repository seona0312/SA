#ifndef __INODE_H_F2DBDC40_6196_4E67_A689_D31A9310BEC0__
#define __INODE_H_F2DBDC40_6196_4E67_A689_D31A9310BEC0__

#if defined XWIN32
#pragma pack(1)
#endif
typedef struct
#if defined LINUX
__attribute__((packed))
#endif
{
  int32_t (*inode_wss_write)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);
  int32_t (*inode_wss_fdset)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);
  int32_t (*inode_httpd_write)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);
  int32_t (*inode_httpd_fdset)(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o);
  void* log;
  void* obj;
  void* hdl;
} iNode;
#if defined XWIN32
#pragma pack()
#endif

#if defined __cplusplus
extern "C"
#endif
#if defined XWIN32 || defined WINCE
__declspec(dllexport)
#endif
void* nmain(void* hdl, void** _wss_iohandler, void** _httpd_iohandler, void** iohandler, void* obj);

#endif