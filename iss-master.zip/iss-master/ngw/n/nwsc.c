#include <nwsc.h>
#include <nutil.h>

static cnwsc gwsc;


int32_t nwsc_Connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnwsc* p = (cnwsc*)o;
  printf(" nwsc_Connected   ->   %08X %d\r\n", sz, p->conn_status);

  p->conn_status = 1;
  return 0;
}

int32_t nwsc_Disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnwsc* p = (cnwsc*)o;
  printf(" nwsc_Disconnected   ->   %08X \r\n", sz);

  p->conn_status = -1;
  return 0;
}


int32_t nwsc_Read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnwsc* p = (cnwsc*)o;
  printf(" nwsc_Read   ->   %08X \r\n", sz);

  return 0;
}

int32_t nwsc_Open(cnwsc* p)
{
  int32_t e = 0;

  p->icd.callback[ICODE_CALLBACK_CONNECTED] = nwsc_Connected;
  p->icd.callback[ICODE_CALLBACK_DISCONNECTED] = nwsc_Disconnected;
  p->icd.callback[ICODE_CALLBACK_READ] = nwsc_Read;
  
  e = __ws_open(&p->icd.h, "{\"IP\":\"127.0.0.1\",\"PORT\":\"7810\",\"CSTYPE\":\"CLIENT\"}", p->icd.callback, p);
  return e;
}


int32_t nwsc_Close(cnwsc* p)
{
  return __ws_close(&p->icd.h);
}


void nwsc(iNode* p)
{
  int32_t e = 0;
  uint8_t b[16] = {0};
  uint8_t hex = 0;
  gwsc.ind = p;
  gwsc.icd.log = p->log;
  gwsc.conn_status = 0;


  while ( 1 )
  {

    printf(" nwsc.conn_status %d \r\n", gwsc.conn_status );

    if ( gwsc.conn_status == 0 )
    {
      delay(2000);
      e = nwsc_Open(&gwsc);
      printf("nwsc_Open : %08X \r\n", e);

      if ( gwsc.conn_status == 0 )
      {
        gwsc.conn_status = -2;
      }
    }


    delay(1000);

    if ( gwsc.conn_status == -1 )
    {
      delay(2000);
      e = nwsc_Close(&gwsc);
      printf("nwsc_Close : %08X \r\n", e);
      gwsc.conn_status = 0;
    }


    if ( gwsc.conn_status == 1 )
    {
      int32_t i = 0;
      delay(500);
      for ( i=0 ; i<16 ;i++ )
      {
        b[i] = hex%26 + 'A';
      }
      e = __ws_write(gwsc.icd.h, 0, b, 16, 0, &gwsc);

      printf(" write (%d)-> %02X \r\n", e, b[0]);

      hex++;
    }
  }


}
