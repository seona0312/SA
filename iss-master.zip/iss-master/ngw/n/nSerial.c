#include <nSerial.h>
#include <nutil.h>

static cnSerial gserial;


int32_t nSerial_Connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnSerial* p = (cnSerial*)o;
  printf(" nSerial_Connected   ->   %08X\r\n", sz);
  return 0;
}

int32_t nSerial_Disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnSerial* p = (cnSerial*)o;
  printf(" nSerial_Disconnected   ->   %08X \r\n", sz);

  return 0;
}


int32_t nSerial_Read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnSerial* p = (cnSerial*)o;
  printf(" nSerial_Read   ->   %08X \r\n", sz);

  return 0;
}

int32_t nSerial_Open(cnSerial* p)
{
  int32_t e = 0;

  p->icd.callback[ICODE_CALLBACK_CONNECTED] = nSerial_Connected;
  p->icd.callback[ICODE_CALLBACK_DISCONNECTED] = nSerial_Disconnected;
  p->icd.callback[ICODE_CALLBACK_READ] = nSerial_Read;
  
  e = __serial_open(&p->icd.h, "{\"PORT\":\"COM3\",\"BAUDRATE\":\"115200\",\"DATABIT\":\"8\",\"STOPBIT\":\"1\",\"PARITYBIT\":\"0\",\"SYNC\":\"DISABLE\"}", p->icd.callback, p);
  return e;
}


int32_t nSerial_Close(cnSerial* p)
{
  return __serial_close(&p->icd.h);
}


void nSerial(iNode* p)
{
  int32_t e = 0;
  uint8_t b[16] = {0};
  uint8_t hex = 0;
  gserial.ind = p;
  gserial.icd.log = p->log;

  while ( 1 )
  {

    nSerial_Open(&gserial);
    delay(500);


    __serial_write(gserial.icd.h, 0, "1234", 4, 0, p);
    delay(1000);

    nSerial_Close(&gserial);
    delay(500);

  }


}
