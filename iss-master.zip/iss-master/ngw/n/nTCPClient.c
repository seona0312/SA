#include <nTCPClient.h>
#include <nutil.h>

static cnTCPClient gtcpclnt;


int32_t nTCPClient_Connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnTCPClient* p = (cnTCPClient*)o;
  printf(" nTCPClient_Connected   ->   %08X %d\r\n", sz, p->conn_status);

  p->conn_status = 1;
  return 0;
}

int32_t nTCPClient_Disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnTCPClient* p = (cnTCPClient*)o;
  printf(" nTCPClient_Disconnected   ->   %08X \r\n", sz);

  p->conn_status = -1;
  return 0;
}


int32_t nTCPClient_Read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnTCPClient* p = (cnTCPClient*)o;
  printf(" nTCPClient_Read   ->   %08X \r\n", sz);

  return 0;
}

int32_t nTCPClient_Open(cnTCPClient* p)
{
  int32_t e = 0;

  p->icd.callback[ICODE_CALLBACK_CONNECTED] = nTCPClient_Connected;
  p->icd.callback[ICODE_CALLBACK_DISCONNECTED] = nTCPClient_Disconnected;
  p->icd.callback[ICODE_CALLBACK_READ] = nTCPClient_Read;
  
  e = __socket_open(&p->icd.h, "{\"IP\":\"127.0.0.1\",\"PORT\":\"7870\",\"CSTYPE\":\"CLIENT\",\"PROTOCOL\":\"TCP\",\"CASTTYPE\":\"UNICAST\",\"SYNC\":\"DISABLE\",\"TIMEOUT\":\"2000\"}", p->icd.callback, p);
  return e;
}


int32_t nTCPClient_Close(cnTCPClient* p)
{
  return __socket_close(&p->icd.h);
}


void nTCPClient(iNode* p)
{
  int32_t e = 0;
  uint8_t b[16] = {0};
  uint8_t hex = 0;
  gtcpclnt.ind = p;
  gtcpclnt.icd.log = p->log;
  gtcpclnt.conn_status = 0;


  //while ( 1 )
  //{

  //  delay(500);
  //  e = nTCPClient_Open(&gtcpclnt);
  //  printf("nTCPClient_Open : %08X \r\n", e);

  //  delay(2500);

  //  e = nTCPClient_Close(&gtcpclnt);
  //  printf("nTCPClient_Close : %08X \r\n", e);
  //}

  while ( 1 )
  {

    printf(" gtcpclnt.conn_status %d \r\n", gtcpclnt.conn_status );

    if ( gtcpclnt.conn_status == 0 )
    {
      delay(2000);
      e = nTCPClient_Open(&gtcpclnt);
      printf("nTCPClient_Open : %08X \r\n", e);
      gtcpclnt.conn_status = -2;
    }


    delay(1000);

    if ( gtcpclnt.conn_status == -1 )
    {
      delay(2000);
      e = nTCPClient_Close(&gtcpclnt);
      printf("nTCPClient_Close : %08X \r\n", e);
      gtcpclnt.conn_status = 0;
    }


    if ( gtcpclnt.conn_status == 1 )
    {
      int32_t i = 0;
      delay(500);
      for ( i=0 ; i<16 ;i++ )
      {
        b[i] = hex%26 + 'A';
      }
      e = __socket_write(gtcpclnt.icd.h, 0, b, 16, 0, &gtcpclnt);

      printf(" write (%d)-> %02X \r\n", e, b[0]);

      hex++;
    }
  }


}
