#include <nTCPServer.h>
#include <nutil.h>

static cnTCPServer gtcpsvr;


void* DisplayFDSet(iCodeFDSET* p)
{
  int32_t i = 0;
  for ( i=0 ; i<p->max ; i++ )
  {
    if ( i && (i%16)==0 ) printf("\r\n");
    if ( i && (i%8)==0 ) printf("  ");
    printf("%8d", (uint32_t)(p->fds+i)->a[0]);
  }
  printf("\r\n");
  return 0;
}



void* WebSocketRouting(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnTCPServer* p = (cnTCPServer*)o;
  int32_t i = 0;

  p->icd.fdset.max = p->ind->inode_wss_fdset(p->ind->hdl, fd, b, sz, &p->icd.fdset.fds, o);

  //DisplayFDSet(&p->icd.fdset);

  //TopRun* p = (TopRun*)h;
  //uint8_t hbuf[8192] = {0};
  //uint32_t hsz = 0;
  //int32_t fd = 0;

  //if ( p->_wss == 0 ) return 0;


  for ( i=0 ; i<p->icd.fdset.max; i++ )
  {
    if ( p->icd.fdset.fds->a[0]>0) p->ind->inode_wss_write(p->ind->hdl, p->icd.fdset.fds->a[0], b, sz, 0, o);
  }
  return 0;
}





int32_t nTCPServer_Connected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf(" nTCPServer_Connected   ->   %08X \r\n", sz);

  return 0;
}

int32_t nTCPServer_Disconnected(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  printf(" nTCPServer_Disconnected   ->   %08X \r\n", sz);
  return 0;
}


int32_t nTCPServer_Read(void* h, int32_t fd, int8_t* b, int32_t sz, void* moreinfo, void* o)
{
  cnTCPServer* p = (cnTCPServer*)o;
  int8_t rbuf[8192] = {0};
  int32_t rsz = 0;

  iCodeFDSET* fdsets = (iCodeFDSET*)moreinfo;
  //to_raw(b, sz, rbuf, &rsz);

  WebSocketRouting(h, fd, b, sz, moreinfo, o);

  p->icd.log("TCPServer_Read", "%s\r\n", rbuf);
  //BOX("nTCPServer_Read");
  //printf("%s\r\n", rbuf);
  //DisplayFDSet(fdsets);

  
  return 0;
}


int32_t nTCPServer_Open(cnTCPServer* p)
{
  p->icd.callback[ICODE_CALLBACK_CONNECTED] = nTCPServer_Connected;
  p->icd.callback[ICODE_CALLBACK_DISCONNECTED] = nTCPServer_Disconnected;
  p->icd.callback[ICODE_CALLBACK_READ] = nTCPServer_Read;
  return __socket_open(&p->icd.h, "{\"IP\":\"127.0.0.1\",\"PORT\":\"7870\",\"CSTYPE\":\"SERVER\",\"PROTOCOL\":\"TCP\",\"CASTTYPE\":\"UNICAST\",\"SYNC\":\"DISABLE\",\"TIMEOUT\":\"100000000\"}", p->icd.callback, p);
}

int32_t nTCPServer_Close(cnTCPServer* p)
{
  return __socket_close(&p->icd.h);
}


void nTCPServer(iNode* p)
{
  gtcpsvr.ind = p;
  gtcpsvr.icd.log = p->log;
  nTCPServer_Open(&gtcpsvr);
}
